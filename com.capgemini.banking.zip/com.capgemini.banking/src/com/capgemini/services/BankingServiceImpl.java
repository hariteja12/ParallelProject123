package com.capgemini.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bean.Account;
import com.capgemini.exceptions.*;


public class BankingServiceImpl implements BankingService {
	static Scanner sc = new Scanner(System.in);

	

	Map<Integer, Account> accounts = new HashMap<Integer, Account>();

	@Override
	public void createAccount(Account account) {
		Integer accno = account.getAccno();
		accounts.put(accno, account);
		System.out.println(accounts);
		
	}

	@Override
	public void deposit(double amount, Integer accno) throws AccountNotFoundException {
		double curbal = 0;

		if (accounts.containsKey(accno)) {
			curbal += accounts.get(accno).getInitialbalance() + amount;
			accounts.get(accno).setInitialbalance(curbal);
			Transaction transaction = new Transaction("CR", "Deposited", amount);
			accounts.get(accno).addTransaction(transaction);
			System.out.println("deposit done successfully");
			
			
		} else {

			try {
				throw new AccountNotFoundException(accno, "account not found");
			} catch (AccountNotFoundException e) {

			}

		}

	}

	@Override
	public void withDraw(double amount, Integer accno) throws AccountNotFoundException, InsufficientBalanceException {
		double curbal = 0;
		if (accounts.containsKey(accno)) {
			if (accounts.get(accno).getInitialbalance() >= amount) {
				curbal += accounts.get(accno).getInitialbalance() - amount;
				accounts.get(accno).setInitialbalance(curbal);
				Transaction transaction = new Transaction("DR", "Debited", amount);
				accounts.get(accno).addTransaction(transaction);
				System.out.println("withdrawl is done");
			} else {

				throw new InsufficientBalanceException(accno, " has Insufficient balance");
			}
		} else {

			throw new AccountNotFoundException(accno, "account not found");
		}
	}

	@Override
	public void showBalance(Integer accno) throws AccountNotFoundException {
		if (accounts.containsKey(accno)) {
			System.out.println("balance in account= " + accounts.get(accno).getInitialbalance());
		} else {
			throw new AccountNotFoundException(accno, "account not found");
		}

	}

	@Override
	public void fundTransfer(Integer accno1, Integer accno2)
			throws InsufficientBalanceException, AccountMismatchException {
		double senderInitial = 0, receiveamt = 0, amount = 0;
		if (accno1.equals(accno2))
			throw new AccountMismatchException(accno1, accno2, "are same");
		else {
			senderInitial = accounts.get(accno1).getInitialbalance();
			receiveamt = accounts.get(accno2).getInitialbalance();
			System.out.println("Enter amount to be transfered");
			amount = sc.nextDouble();
			if (amount > senderInitial) {
				throw new InsufficientBalanceException(accno1, "Amount greater than bankbalance");
			} else {
				receiveamt = accounts.get(accno2).getInitialbalance() + amount;
				senderInitial = accounts.get(accno1).getInitialbalance() - amount;
				accounts.get(accno1).setInitialbalance(senderInitial);
				accounts.get(accno2).setInitialbalance(receiveamt);
				System.out.println("funds transfered");
				Transaction transaction1 = new Transaction("DR", "Deposited", amount);
				accounts.get(accno1).addTransaction(transaction1);
				Transaction transaction = new Transaction("CR", "Deposited", amount);
				accounts.get(accno2).addTransaction(transaction);
			}
		}
	}

	@Override
	public void printTransactions(Integer accNo) throws AccountNotFoundException {
		if (accounts.containsKey(accNo)) {
			List<Transaction> trans = accounts.get(accNo).getTransaction();
			// System.out.println(trans);
			trans.forEach(System.out::println);
		} else {
			throw new AccountNotFoundException(accNo, "Account not found");
		}
	}

}
