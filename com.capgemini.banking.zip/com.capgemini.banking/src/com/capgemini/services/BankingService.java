package com.capgemini.services;

import java.io.FileNotFoundException;

import com.capgemini.bean.*;
import com.capgemini.exceptions.AccountMismatchException;
import com.capgemini.exceptions.AccountNotFoundException;
import com.capgemini.exceptions.InsufficientBalanceException;

public interface BankingService {

	void  createAccount(Account account);

	void deposit(double amount, Integer accno) throws AccountNotFoundException;

	void withDraw(double amount, Integer accno) throws AccountNotFoundException, InsufficientBalanceException;

	void fundTransfer(Integer accno1, Integer accno2) throws AccountNotFoundException, InsufficientBalanceException, AccountMismatchException;

	void showBalance(Integer accno) throws AccountNotFoundException;

	void printTransactions(Integer accNo) throws AccountNotFoundException;
	
}
