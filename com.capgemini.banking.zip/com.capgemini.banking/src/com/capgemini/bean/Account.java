package com.capgemini.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.capgemini.services.*;

public class Account implements Serializable {

	static Integer accno = 102808087;
	ArrayList<Transaction> arrayList;
	private Customer customer;
	private String accType;
	private double initialbalance;

	public Account(ArrayList<Transaction> arrayList, Customer customer, String accType, double initialbalance) {
		super();
		this.arrayList = new ArrayList<Transaction>();
		this.customer = customer;
		this.accType = accType;
		this.initialbalance = initialbalance;
	}

	public Account() {
		super();
		this.arrayList = new ArrayList<Transaction>();
	}

	public void addTransaction(Transaction transaction) {
		this.arrayList.add(transaction);
	}

	public ArrayList<Transaction> getTransaction() {
		return arrayList;
	}

	public void setInitialbalance(double initialbalance) {
		this.initialbalance = initialbalance;
	}

	public double getInitialbalance() {
		return initialbalance;
	}

	public Integer getAccno() {
		return accno++;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	@Override
	public String toString() {
		return "Account [arrayList=" + arrayList + ", customer=" + customer + ", accType=" + accType
				+ ", initialbalance=" + initialbalance + "]";
	}

}
